
/***********************************
 * Create Code Snippets
 *********************************** */



 /***********************************
 * Challenge Seed Template
 *********************************** */

 /*
  {
   title: ``,
 	subtitle: ``,
   choices: [
  	 ``,
  	 ``,
  	 ``,
  	 ``
   ],
   solution: ``,
   explanation: ``
  },
 */

/***********************************
 * Export Challenge Array
 *********************************** */

export default {
	title: `Design Principles`,
	category: `Design Principles`,
	challenges: [
		{
			title: ``,
			subtitle: ``,
			choices: [
				``,
				``,
				``,
				``
			],
			solution: ``,
			explanation: ``
	  },
	]
};
