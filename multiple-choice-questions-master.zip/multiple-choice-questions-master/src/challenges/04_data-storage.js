
/***********************************
 * Create Code Snippets
 *********************************** */



 /***********************************
 * Challenge Seed Template
 *********************************** */

 /*
  {
   title: ``,
 	subtitle: ``,
   choices: [
  	 ``,
  	 ``,
  	 ``,
  	 ``
   ],
   solution: ``,
   explanation: ``
  },
 */

/***********************************
 * Export Challenge Array
 *********************************** */

export default {
	title: `Data Storage`,
	category: `Data Storage`,
	challenges: [
		{
			title: `Placeholder...`,
			subtitle: `Placeholder...`,
			choices: [
				`A`,
				`B`,
				`C`,
				`D`
			],
			solution: ``,
			explanation: ``
		}
	]
};
